package com.lagradost.cloudstream3.network

import kotlin.concurrent.Volatile
import okhttp3.Request

/**
 * SkyStream: resolves pages for the app that embeds this library, in its own browser. Unset,
 * WebViewResolver works as upstream's: Android's in a WebView of its own, and the JVM's finds
 * nothing.
 */
object WebViewResolverHost {
    @Volatile
    var resolver: Resolver? = null

    interface Resolver {
        suspend fun resolve(
            resolver: WebViewResolver,
            request: Request,
            requestCallBack: (Request) -> Boolean,
        ): Pair<Request?, List<Request>>
    }
}
